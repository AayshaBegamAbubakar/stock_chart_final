package com.stock.stockexchange.model;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;

@Entity
@Table(name = "user")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id")
	private int userId;

	@Pattern(regexp = "^[ A-Za-z]+$", message = "Name should not contain numbers")
	@Size(min = 3, max = 50, message = "First Name should be between 3 and 50 characters")

	@Column(name = "user_name")
	private String userName;
	@Size(min = 3, max = 20, message = "Password should be between 3 and 20 characters")

	@Column(name = "password")
	private String password;

	@Column(name = "secret_question")
	private String secretQuestion;

	@Column(name = "user_type")
	private String userType;

	@Email(message = "please enter proper email")

	@Column(name = "email")
	private String email;

	@Range(min = 1000000000, message = "Contact number must be 10 digits")
	@Column(name = "mobile_number")
	private long mobileNumber;

	@Column(name = "confirmed")
	private String confirmed;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getConfirmed() {
		return confirmed;
	}

	public void setConfirmed(String confirmed) {
		this.confirmed = confirmed;
	}

	public String getSecretQuestion() {
		return secretQuestion;
	}

	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}

}
