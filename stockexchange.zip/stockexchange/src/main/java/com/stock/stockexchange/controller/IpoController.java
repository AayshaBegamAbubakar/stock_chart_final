package com.stock.stockexchange.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.stock.stockexchange.model.CompanyWithoutMapping;
import com.stock.stockexchange.model.IpoWithoutMapping;
import com.stock.stockexchange.service.IpoService;

@Controller
@RequestMapping("/ipoController")
public class IpoController {
	@Autowired
	IpoService ipoService;
	
	@GetMapping(path = "/fetchIpo")
	public ModelAndView getFetchIpo(Model model) {
		System.out.println("fetch ipo controller");
		
		ModelAndView mv = new ModelAndView();
		List<IpoWithoutMapping> fetchIpo=new ArrayList<IpoWithoutMapping>();
		try {
			fetchIpo = ipoService.getIpolist();
					
		if (fetchIpo != null) {
				System.out.println("get all ipo list");
				model.addAttribute("fetch", fetchIpo);
				mv.setViewName("FetchIpo");
			} else {
				System.out.println("ipo is not listed");
				model.addAttribute("list", "there is something error in controller");
				mv.setViewName("Error");
			}
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
		

		return mv;


	}

	@GetMapping(path = "/updateIpo")
	public ModelAndView getUpdateIpo(@RequestParam("ipoId") int ipoId,ModelMap model) {
		System.out.println("update ipo controller "+ipoId);
		
		ModelAndView mv = new ModelAndView();
		IpoWithoutMapping  updateIpo=new 	IpoWithoutMapping();
			updateIpo = ipoService.getUpdateIpoByIpoId(ipoId);
			if (updateIpo != null) {
				System.out.println("get ipo list by company code");
				model.addAttribute("ipo", updateIpo);
				mv.setViewName("UpdateIpo");
			} else {
				System.out.println("Ipo is not listed");
				model.addAttribute("list", "there is something error in controller");
				mv.setViewName("Error");
			}
		
		

		return mv;


	}
	
	@PostMapping(path = "/saveEditedIpo")
	public String getSaveEditedCompany(@Valid @ModelAttribute("ipo") IpoWithoutMapping ipo,

			BindingResult result, Model model) {

		String insertIpo = null;
		System.out.println("edit ipo  controller ");
IpoWithoutMapping  createIpo;
		if (result.hasErrors()) {

			model.addAttribute("ipo", ipo);

			insertIpo= "CreateIpo";

		}
		try {
			System.out.println("ipo  insert method in service calling");
			createIpo = ipoService.insertIpo(ipo);

			if (createIpo != null) {
				System.out.println("after user inserted");
				insertIpo= "redirect:/ipoController/fetchIpo";

				System.out.println(insertIpo);
			} else {
				System.out.println(" ipo not inserted");

			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return insertIpo;

	}


	@GetMapping(path = "/deleteIpo")
	public String getDeleteipo(@RequestParam("ipoId") int ipoId,ModelMap model) {

		String deleteIpo = null;
		System.out.println("delete ipo  controller ");
int numberOfDeletedRows;
		
			System.out.println("ipo  delete method in service calling");
			numberOfDeletedRows= ipoService.deleteIpo(ipoId);

			if (numberOfDeletedRows != 0) {
				System.out.println("after user deleted");
				deleteIpo= "redirect:/companyController/fetchipo";

				System.out.println(deleteIpo);
			} else {
				System.out.println(" ipo not deleted");

			}
		


		return deleteIpo;

	}


}
