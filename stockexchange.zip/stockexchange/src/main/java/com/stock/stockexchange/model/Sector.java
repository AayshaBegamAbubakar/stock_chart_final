package com.stock.stockexchange.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "sector")
public class Sector {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "sector_id")
	private int sectorId;

	@Column(name = "sector_name")
	private String sectorName;

	@Column(name = "sector_brief")
	private String sectorBrief;

	@OneToMany(mappedBy = "sectors",fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@Column(nullable = true)
	@JsonManagedReference
	private List<Company> companyList;

	public int getSectorId() {
		return sectorId;
	}

	public void setSectorId(int sectorId) {
		this.sectorId = sectorId;
	}

	public String getSectorName() {
		return sectorName;
	}

	public void setSectorName(String sectorName) {
		this.sectorName = sectorName;
	}

	public String getSectorBrief() {
		return sectorBrief;
	}

	public void setSectorBrief(String sectorBrief) {
		this.sectorBrief = sectorBrief;
	}

	public List<Company> getCompanyList() {
		return companyList;
	}

	
 
}
