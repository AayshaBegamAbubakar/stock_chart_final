package com.stock.stockexchange.service;

import java.sql.SQLException;
import java.util.List;

import com.stock.stockexchange.model.CompanyWithoutMapping;
import com.stock.stockexchange.model.Sector;

public interface CompanyService {
      
	//Insert Company
	public CompanyWithoutMapping insertCompany(CompanyWithoutMapping company) throws SQLException;

	//Fetch COmpany List Based on matched Sector Id
	public List<Sector> getCompanyList() throws SQLException, ClassNotFoundException;
  
	//Fetch All Company List
	public List<CompanyWithoutMapping> getCompanylist() throws SQLException, ClassNotFoundException;
 
	//Fetch Company By Matched String letters in Company Name
	public List<CompanyWithoutMapping> findByPattern(String match);

	//Update Company Details Based on given Company code
	public CompanyWithoutMapping getUpdateCompanyByCompanyCode(int companyCode);

	//Delete Company Details Based on selected Company Code
	public int deleteCompany(int companyCode);

}
