package com.stock.stockexchange.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.stock.stockexchange.model.User;
import com.stock.stockexchange.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	UserService userService;

	@RequestMapping(path = "/sign", method = RequestMethod.GET)

	public String getSignForm(ModelMap model) {
		System.out.println("get empty user pojo");
		User user = new User();
		model.addAttribute("user", user);
		System.out.println("go to home page");

		return "Home";

	}

	@RequestMapping(path = "/signup", method = RequestMethod.POST)

	public String getSignUp(@Valid @ModelAttribute("user") User user,

			BindingResult result, Model model) {

		String home = null;
		System.out.println("choose sign up");

		User insertedUser;
		if (result.hasErrors()) {

			model.addAttribute("user", user);

			home = "Home";

		}
		try {
			System.out.println("user  insert method in service calling");
			insertedUser = userService.insertUser(user);

			if (insertedUser != null) {
				System.out.println("after user inserted");
				home = "redirect:/user/sign";

				System.out.println(insertedUser);
			} else {
				System.out.println(" user not inserted");

			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return home;

	}

	@RequestMapping(path = "/signin", method = RequestMethod.POST)

	public ModelAndView getSignIn(@Valid @ModelAttribute("user") User user,

			BindingResult result, Model model,HttpServletRequest request, HttpServletResponse response) throws SQLException {

		System.out.println("inside signin call");
		ModelAndView mv = new ModelAndView();
		User validateUser;
		if (result.hasErrors()) {

			System.out.println("errors occured");

			model.addAttribute("user", user);

			mv.setViewName("Home");

		}
		validateUser = userService.validateUser(user);
		if (validateUser != null) {
			System.out.println("correct username and password");
			HttpSession session = request.getSession();
			session.setAttribute("username", user.getUserName());

			System.out.println(validateUser);
			
			
			mv.setViewName("StockMarket");
		} else {
			System.out.println("Wrong user");
			model.addAttribute("invalid", " Wrong Username and Password");
			mv.setViewName("Home");
		}

		return mv;

	}

	@RequestMapping(path = "/resetPassword", method = RequestMethod.POST)

	public ModelAndView getResetPassword(@Valid @ModelAttribute("user") User user,

			BindingResult result, Model model) throws SQLException {

		System.out.println("inside reset call");
		ModelAndView mv = new ModelAndView();
		User resetPassword = null;
		User resetUser;
		
		System.out.println("user reset  method calling");
		resetUser = userService.resetPassword(user);
		System.out.println("after reset call");
		if (resetUser != null) {
			resetUser.setPassword(user.getPassword());
			System.out.println("before insert new password");
			resetPassword = userService.insertUser(resetUser);

			if (resetPassword != null) {
				System.out.println(" inserted  password");
				System.out.println(resetPassword);
				mv.setViewName("Home");
			} else {
				System.out.println("Wrong user");
			}

		} else {
			System.out.println("Wrong user");
			model.addAttribute("invalid", " Wrong Username and Secret Question");
			mv.setViewName("Home");
		}

		return mv;

	}

}
