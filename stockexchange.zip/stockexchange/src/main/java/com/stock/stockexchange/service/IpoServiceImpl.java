package com.stock.stockexchange.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.stockexchange.dao.IpoPlannedDao;
import com.stock.stockexchange.model.CompanyWithoutMapping;
import com.stock.stockexchange.model.IpoWithoutMapping;
@Service
public class IpoServiceImpl implements IpoService {
 
	@Autowired
	IpoPlannedDao ipoPlannedDao;
	@Override
	public IpoWithoutMapping insertIpo(IpoWithoutMapping ipo) throws SQLException {
		System.out.println("insert ipo dao");
		return ipoPlannedDao.save(ipo);
	}

	@Override
	public List<IpoWithoutMapping> getIpolist() throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		return ipoPlannedDao.findAll();
	}

	@Override
	public IpoWithoutMapping getUpdateIpoByIpoId(int ipoId) {
		 IpoWithoutMapping fetchIpo=ipoPlannedDao.findByIpoId(ipoId);
		 System.out.println(" fetch ipo by id "+fetchIpo);
		return fetchIpo;
	}

	@Override
	public int deleteIpo(int ipoId) {
		// TODO Auto-generated method stub
		return ipoPlannedDao.deleteCompany(ipoId);
	}

}
