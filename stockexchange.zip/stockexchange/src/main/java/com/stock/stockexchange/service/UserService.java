package com.stock.stockexchange.service;

import java.sql.SQLException;




import com.stock.stockexchange.model.User;

public interface UserService {
   public User insertUser(User user) throws SQLException;

	public User validateUser( User user);

	public User resetPassword(User user);
}
